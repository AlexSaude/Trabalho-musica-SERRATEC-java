package trabalhoMusica;

public class Galo extends Animal{
public Galo(String animal, String som) {
		super(animal, som);
		// TODO Auto-generated constructor stub
	}
private String nome;
private String sexo;

public void emitirSom() {
	System.out.println("la em casa tinha um galo");
	System.out.println("la em casa tinha um galo");
}
	public String Tostring() {
		return "E o galo cocoricó";
	}
	
}