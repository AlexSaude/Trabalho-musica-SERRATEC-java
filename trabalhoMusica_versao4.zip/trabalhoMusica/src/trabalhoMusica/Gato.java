package trabalhoMusica;

public class Gato {
private String nome;
private String sexo;


public Gato() {
	// TODO Auto-generated constructor stub
}

public void emitirSom() {
	System.out.println("la em casa tinha um gato");
	System.out.println("la em casa tinha um gato");
}

public String Tostring() {
	return "E o gato miau";
}
}
