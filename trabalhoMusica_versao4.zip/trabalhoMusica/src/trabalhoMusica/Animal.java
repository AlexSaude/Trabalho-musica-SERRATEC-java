package trabalhoMusica;



public class Animal {
	private String animal;
	private String som;
	
	public Animal(String animal, String som) {
		super();
		this.animal = animal;
		this.som = som;
	}

	public void emitirSom(int flag) {
		// TODO Auto-generated method stub
		
	}

}
