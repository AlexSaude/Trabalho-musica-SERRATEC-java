package trabalhoMusica;

public class Chick extends Animal{
	public Chick(String animal, String som) {
		super(animal, som);
		System.out.println("lá em casa tinha um pintinho");
		System.out.println("lá em casa tinha um pintinho");
	}
	
	@Override
	public void emitirSom(int flag) {
		
		for(int i = 0; i<flag; i++) {
			System.out.println("e o pintinho piu");
			}
	}
}
