package trabalhoMusica;

public class Cachorro {
private String nome;
private String sexo;
public Cachorro(String nome, String sexo) {
	super();
	this.nome = nome;
	this.sexo = sexo;
}
public Cachorro() {
	// TODO Auto-generated constructor stub
}

public void emitirSom() {
	System.out.println("la em casa tinha um cachorro");
	System.out.println("la em casa tinha um cachorro");
}
public String Tostring() {
	return "E o cachorro au au";
}
}
