package trabalhoMusica;

public class Galinha extends Animal{
public Galinha(String animal, String som) {
		super(animal, som);
		// TODO Auto-generated constructor stub
	}

private String nome;
private String sexo;

public void emitirSom() {
	System.out.println("la em casa tinha uma galinha");
	System.out.println("la em casa tinha uma galinha");
}
public String Tostring() {
	return "e a galinha có";
}

}
